﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testerzy.Trainings.CSharp.Framework.Attributes;

[AttributeUsage(AttributeTargets.Field)]
public class ImportantBugAttribute : BugAttribute
{
    public ImportantBugAttribute(string bugId) : base(bugId)
    {
    }
}
