﻿namespace Testerzy.Trainings.CSharp.Tests.Examples;

public class StaticExamples
{
    [Test]
    public void Test()
    {
        Console.WriteLine("info");
        Assert.That(1 + 1, Is.EqualTo(2));

        int number = Convert.ToInt32("12");
    }

    [Test]
    public void TestBalanceInEur()
    {
        var kontoKamila = new BankAccount(1000M);
        var kontoMarka = new BankAccount(2000M);

        BankAccount.PlnToEur = 5;
        //Console.WriteLine(BankAccount.PlnToEur);

        Console.WriteLine($"kontoKamila Balance PLN: {kontoKamila.Balance}");
        Console.WriteLine($"kontoKamila Balance EUR: {kontoKamila.GetBalanceInEur()}");
        Console.WriteLine($"kontoMarka Balance PLN: {kontoMarka.Balance}");
        Console.WriteLine($"kontoMarka Balance EUR: {kontoMarka.GetBalanceInEur()}");

        BankAccount.PlnToEur = 4.5m;

        Console.WriteLine($"kontoKamila Balance PLN: {kontoKamila.Balance}");
        Console.WriteLine($"kontoKamila Balance EUR: {kontoKamila.GetBalanceInEur()}");
        Console.WriteLine($"kontoMarka Balance PLN: {kontoMarka.Balance}");
        Console.WriteLine($"kontoMarka Balance EUR: {kontoMarka.GetBalanceInEur()}");

        BankAccount.MetodaStatyczna();

        //int number = BankAccount.GetInt();

        //var staticClassObject = new StaticCLass();
    }

    [Test]
    public void Test1()
    {
        string username1 = UsernameHelper.CreateUsername();
        string username2 = UsernameHelper.CreateUsername("DEV");
        string username3 = UsernameHelper.CreateUsername("PROD");

        string a = Constants.Header;
        string b = Constants.ApiResponses.AccountsEndpoint;
    }
}
