﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Testerzy.Trainings.CSharp.Framework;
using Testerzy.Trainings.CSharp.Tests.EncExamples;

namespace Testerzy.Trainings.CSharp.Tests.Tests;
internal class HermeTests
{
    [Test]
    public void Test()
    {
        var obiektKlasyBazowej = new KlasaBazowa();
        obiektKlasyBazowej.PublicznaMetodaKlasaBazowa();
        obiektKlasyBazowej.publicznePoleKlasaBazowa = 12;
        //obiektKlasyBazowej.prywatnePoleKlasaBazowa = 144; brak dostepu
        //obiektKlasyBazowej.ProtectedMetodaKlasaBazowa(); brak dostepu

        var obiektKlasyPochodnej = new KlasaPochodna();
        obiektKlasyPochodnej.PublicznaMetodaKlasaPochodna();
        obiektKlasyPochodnej.publicznePoleKlasaPochodna = 1;
        obiektKlasyPochodnej.PublicznaMetodaKlasaBazowa();
        obiektKlasyPochodnej.publicznePoleKlasaBazowa = 12;
        //obiektKlasyPochodnej.prywatnePoleKlasaBazowa = 13313; brak dostepu
        //obiektKlasyPochodnej.ProtectedMetodaKlasaBazowa(); brak dostepu

        var KlasaPublicznaFramework = new KlasaPublicznaFramework();
        //var KlasaInternalFramework = new KlasaInternalFramework();
    }
}
