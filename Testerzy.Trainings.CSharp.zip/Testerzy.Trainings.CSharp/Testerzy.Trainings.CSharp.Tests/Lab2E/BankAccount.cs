﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testerzy.Trainings.CSharp.Tests.Lab2E;

public class BankAccount
{
    private decimal _balance;

    public void Deposit(decimal amount)
    {
        _balance += amount; // _balance = _balance + amount;
    }

    public decimal GetBalance()
    {
        //Console.WriteLine("zwracamy stan konta");
        return _balance;
    }

    public decimal GetBalance1() => _balance;
}
