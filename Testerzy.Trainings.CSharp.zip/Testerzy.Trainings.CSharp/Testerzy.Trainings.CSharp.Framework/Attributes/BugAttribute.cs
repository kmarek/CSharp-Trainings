﻿namespace Testerzy.Trainings.CSharp.Framework.Attributes;

[AttributeUsage(AttributeTargets.Method
    | AttributeTargets.Class, AllowMultiple = true)]
public class BugAttribute : Attribute
{
    public string BugId { get; set; }
    //public BugAttribute() { }

    public BugAttribute(string bugId)
    {
        BugId = bugId;
    }
}
