﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testerzy.Trainings.CSharp.Tests.Lab2G;

public class RestClient
{
    public string Send(RestRequest restRequest)
    {
        return restRequest.Url;
    }

    public string Send(RestRequest restRequest, string method)
    {
        return $"{method} {restRequest.Url}";
    }
}
