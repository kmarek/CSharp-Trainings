﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testerzy.Trainings.CSharp.Tests.Examples;

public static class UsernameHelper
{
    public static string CreateUsername()
    {
        return "losowa nazwa uzytkownika";
    }

    public static string CreateUsername(string environmentName)
    {
        return $"{environmentName}randomUsername";
    }
}
