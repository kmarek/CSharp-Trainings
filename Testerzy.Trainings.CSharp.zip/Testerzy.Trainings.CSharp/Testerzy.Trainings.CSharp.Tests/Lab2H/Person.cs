﻿namespace Testerzy.Trainings.CSharp.Tests.Lab2H;

public class Person
{
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public BankAccount BankAccount { get; set; } = new BankAccount();
}
