﻿using NUnit.Framework.Interfaces;

namespace Testerzy.Trainings.CSharp.Tests.Tasks;

public class Lab5CTests
{
    private static int count;

    [OneTimeSetUp]
    public void OneTimeSetup()
    {
        count = 0;
    }

    [SetUp]
    public void SetUp()
    {
        Console.WriteLine("Setup");
    }

    [Test, Ignore("BUG 124")]
    [Property("TestLevel", "UAT")]
    public void VerifyIgnore()
    {

    }

    [Test, Repeat(5)]
    [Property("TestType", "Sanity")]
    [Property("TestLevel", "UAT")]
    [Property("TestLovel", "UAT")]
    public void VerifyRepeat()
    {
        Console.WriteLine("verify repeat");
    }

    [Test, Retry(2)]
    [Property("TestType", "Smoke")]
    public void VerifyRetry()
    {
        Console.WriteLine($"Verify retry count = {count}");
        count++;
        Assert.That(count, Is.EqualTo(2));
    }

    [TearDown]
    public void TearDown()
    {
        TestStatus status = TestContext.CurrentContext.Result.Outcome.Status;

        if (status == TestStatus.Failed)
        {
            Console.WriteLine("TestFailed");
        }
    }
}
