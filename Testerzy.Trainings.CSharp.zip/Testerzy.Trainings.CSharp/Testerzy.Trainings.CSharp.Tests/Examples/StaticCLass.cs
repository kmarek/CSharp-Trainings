﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testerzy.Trainings.CSharp.Tests.Examples;

internal static class StaticCLass
{
    public const int UsdToPln = 12;
}
