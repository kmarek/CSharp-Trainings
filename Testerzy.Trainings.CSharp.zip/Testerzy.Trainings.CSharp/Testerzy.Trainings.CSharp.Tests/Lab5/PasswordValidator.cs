﻿using System.Text.RegularExpressions;

namespace Testerzy.Trainings.CSharp.Tests.Lab5;

public class PasswordValidator
{
    private const string pattern = @"^(?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?=.*[^\w\d\s:])([^\s]){8,16}$";

    public bool IsPasswordValid(string password)
    {
        return Regex.IsMatch(password, pattern);
    }
}
