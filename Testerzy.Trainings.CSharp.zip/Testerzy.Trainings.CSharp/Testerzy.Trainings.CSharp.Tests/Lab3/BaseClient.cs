﻿namespace Testerzy.Trainings.CSharp.Tests.Lab3;

public class BaseClient
{
    private string _baseUrl;

    public BaseClient(string baseUrl)
    {
        bool isNullOrEmpty = string.IsNullOrEmpty(baseUrl);

        if (isNullOrEmpty)
        {
            throw new ArgumentException("jest null or empty");
        }

        bool isValidUrl = Uri.IsWellFormedUriString(baseUrl, UriKind.Absolute);
        if (!isValidUrl)
        {
            throw new ConfigurationException("Please provide valid URL");
        }

        _baseUrl = baseUrl;
    }

    public string GetBaseUrl()
    {
        return _baseUrl;
    }
}
