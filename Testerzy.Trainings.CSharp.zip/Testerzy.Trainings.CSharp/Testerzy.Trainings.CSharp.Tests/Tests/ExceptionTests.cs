﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Testerzy.Trainings.CSharp.Tests.Exceptions;

namespace Testerzy.Trainings.CSharp.Tests.Tests;
internal class ExceptionTests
{
    [Test]
    public void TestException()
    {
        //throw new TestException("wiadomosc do wyjatku");
    }

    [Test]
    public void TestException1()
    {
        try
        {
            int number = Convert.ToInt32("sdfsdf");
        }
        catch (FormatException ex)
        {
            throw new TestException("wiadomosc do wyjatku", ex);
        }

    }
}
