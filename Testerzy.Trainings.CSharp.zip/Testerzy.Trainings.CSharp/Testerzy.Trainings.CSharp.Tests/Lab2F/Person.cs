﻿namespace Testerzy.Trainings.CSharp.Tests.Lab2F;

public class Person
{
    public string FirstName { get; private set; }

    public Person(string firstName)
    {
        FirstName = firstName;
    }

    public void Introduce()
    {
        Console.WriteLine($"Hello, I'm {FirstName}");
    }

    public void Introduce(string name)
    {
        Console.WriteLine($"Hello {name}, I'm {FirstName}");
    }
}
