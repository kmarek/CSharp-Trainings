﻿namespace Testerzy.Trainings.CSharp.Tests.Lab2C;

public class Student : Person
{
    public string studentCardNumber;
}
