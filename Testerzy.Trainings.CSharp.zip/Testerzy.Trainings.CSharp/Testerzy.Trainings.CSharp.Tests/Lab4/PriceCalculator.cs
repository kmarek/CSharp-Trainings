﻿namespace Testerzy.Trainings.CSharp.Tests.Lab4;

public class PriceCalculator
{
    public static int GetPrice(Month month)
    {
        int price = 0;

        switch (month)
        {
            case Month.May:
            case Month.June:
            case Month.September:
                price = 300;
                break;
            case Month.July:
            case Month.August:
                price = 400;
                break;
            default:
                price = 200;
                break;
        }

        return price;
    }

    public static int GetPriceVersion2(Month month)
    {
        int price = 200;

        if (month == Month.May || month == Month.June || month == Month.September)
        {
            price = 300;
        }
        else if (month == Month.July || month == Month.August)
        {
            price = 400;
        }

        return price;
    }

    public static int GetPriceVersion3(Month month)
    {
        switch (month)
        {
            case Month.May:
            case Month.June:
            case Month.September:
                return 300;
            case Month.July:
            case Month.August:
                return 400;
            default:
                return 200;
        }
    }

    public static int GetPriceVersion4(Month month)
    {
        return month switch
        {
            Month.May or Month.June or Month.September => 300,
            Month.July or Month.August => 400,
            _ => 200,
        };
    }

    public static int GetPriceVersion5(Month month)
    {
        return (int)month;
    }
}
