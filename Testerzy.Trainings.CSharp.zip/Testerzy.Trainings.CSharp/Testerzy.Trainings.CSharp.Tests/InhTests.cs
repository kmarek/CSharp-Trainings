﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Testerzy.Trainings.CSharp.Tests.Eamples2;

namespace Testerzy.Trainings.CSharp.Tests;

public class InhTests
{
    [Test]
    public void Test1()
    {
        var polonez = new Polonez();

        var polonez1 = new Polonez("RED");

        var car = new Car("");
        //
    }
}
