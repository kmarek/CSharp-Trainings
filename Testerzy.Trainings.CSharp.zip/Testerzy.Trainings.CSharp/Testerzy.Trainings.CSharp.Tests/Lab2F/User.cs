﻿namespace Testerzy.Trainings.CSharp.Tests.Lab2F;
internal class User
{
    public string FirstName { get; set; }
}
