﻿using Testerzy.Trainings.CSharp.Tests.Enums;

namespace Testerzy.Trainings.CSharp.Tests.Attributes;

[AttributeUsage(AttributeTargets.Method, AllowMultiple = true)]
public class TestCategoryAttribute : PropertyAttribute
{
    public TestCategoryAttribute(TestCategoryName testCategoryName)
        : base("Category", testCategoryName.ToString())
    {

    }
}
