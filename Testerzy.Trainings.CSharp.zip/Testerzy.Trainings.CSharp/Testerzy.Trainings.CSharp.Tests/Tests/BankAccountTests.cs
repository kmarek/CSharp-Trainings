﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Testerzy.Trainings.CSharp.Tests.EncExamples;

namespace Testerzy.Trainings.CSharp.Tests.Tests;

public class BankAccountTests
{
    [Test]
    public void Test()
    {
        var kontoKamila = new BankAccount();
        //kontoKamila._balance = 1000000000;
    }
}
