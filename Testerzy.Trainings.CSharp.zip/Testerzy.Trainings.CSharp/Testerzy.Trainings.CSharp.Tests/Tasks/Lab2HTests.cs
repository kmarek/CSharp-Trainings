﻿using Testerzy.Trainings.CSharp.Tests.Lab2H;

namespace Testerzy.Trainings.CSharp.Tests.Tasks;

public class Lab2HTests
{
    [Test]
    public void TestBankAccountWithPerson()
    {
        var person = new Person();
        person.FirstName = "Kamil";
        person.LastName = "Marek";
        person.BankAccount.AccountNumber = "PL123213";

        Assert.That(person.FirstName, Is.EqualTo("Kamil"));
        Assert.That(person.LastName, Is.EqualTo("Marek"));
        Assert.That(person.BankAccount.AccountNumber, Is.EqualTo("PL123213"));
    }
}
