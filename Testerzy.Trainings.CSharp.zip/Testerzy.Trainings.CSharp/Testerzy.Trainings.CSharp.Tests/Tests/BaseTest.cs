﻿namespace Testerzy.Trainings.CSharp.Tests.Tests;

public class BaseTest
{
    [OneTimeSetUp]
    public void BaseOneTimeSetUp()
    {
        Console.WriteLine("base onetimetearnDOwn");
    }

    [SetUp]
    public void BaseSetUp()
    {
        Console.WriteLine("base setup");
        //Assert.That(1 + 1, Is.EqualTo(0));
    }

    [TearDown]
    public void BaseTearDown()
    {
        Console.WriteLine("base teardown");
    }
}
