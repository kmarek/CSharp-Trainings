﻿namespace Testerzy.Trainings.CSharp.Tests.Lab2B;

public class Person
{
    public string firstName;
    public string lastName;

    public Person() : this("John", "Doe")
    { }

    public Person(string firstName, string lastName)
        : this(123, firstName, lastName)
    {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public Person(int id, string firstName, string lastName)
    {

    }
}
