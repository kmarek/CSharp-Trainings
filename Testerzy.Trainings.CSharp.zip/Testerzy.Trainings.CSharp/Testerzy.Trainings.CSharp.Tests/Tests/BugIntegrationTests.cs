﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Testerzy.Trainings.CSharp.Tests.Tests;

public class BugIntegrationTests : BaseBugTest
{
    [Test]
    public void TestShouldBeSkippe()
    {

    }

    [Test]
    public void TestShouldBeExecuted()
    {

    }
}
