﻿namespace Testerzy.Trainings.CSharp.Tests.Lab2G;

public class RestRequest
{
    public string Url { get; set; }
}
