﻿using Testerzy.Trainings.CSharp.Tests.Lab3;

namespace Testerzy.Trainings.CSharp.Tests.Tasks;

public class Lab3Tests
{

    [Test]
    public void TestIsNUllOrEmpty()
    {
        string zmienna = "";

        bool isNullOrEmpty = string.IsNullOrEmpty(zmienna); // "" lub null lub string.Empty => true
                                                            // w innym przypadku => false


    }

    [Test]
    public void TestExceptionWasThrown()
    {
        bool exceptionThrown = false;
        BaseClient baseClient;
        try
        {
            baseClient = new BaseClient(string.Empty);

            Console.WriteLine();
        }
        catch (ArgumentException e)
        {
            exceptionThrown = true;
            throw;
        }
        finally
        {
            //string url1 = baseClient.GetBaseUrl(); // tak nie
        }
        string url = baseClient.GetBaseUrl();

        Assert.That(exceptionThrown, Is.True);
    }

    [Test]
    public void TestExceptionWasNotThrown()
    {
        bool exceptionThrown = false;

        try
        {
            BaseClient baseClient = new BaseClient("OK URL");
        }
        catch (ArgumentException e)
        {
            exceptionThrown = true;
        }

        Assert.That(exceptionThrown, Is.False);
    }



    [Test]
    public void TestCatch1()
    {
        try
        {
            BaseClient baseClient = new("sds");
        }
        catch (Exception ex)
        {
            Console.WriteLine("Wystapił wyjatek przy tworzeniu BaseClient");

            throw;

        }
        finally
        {
            Console.WriteLine("Finally");
        }

        Console.WriteLine("Ciag dalszy programu");

    }

    [Test]
    public void TestInvalidUrl()
    {
        bool exceptionThrown = false;

        try
        {
            //BaseClient baseClient = new("://api.pl");
            BaseClient baseClient1 = new("");
        }
        catch (ArgumentException)
        {
            Console.WriteLine("Zlapal sie ArgumentExc");
            exceptionThrown = true;
        }
        catch (ConfigurationException)
        {
            Console.WriteLine("Zlapal sie ConfigExc");
            exceptionThrown = true;
        }
        catch (Exception)
        {
            Console.WriteLine("Nie był to ani ArgExce ani ConfigExc");
            exceptionThrown = true;
        }

        Assert.That(exceptionThrown, Is.True);
    }

    [Test]
    public void TestValidUrl()
    {
        bool exceptionThrown = false;

        try
        {
            BaseClient baseClient = new("https://api.pl");
        }
        catch (ConfigurationException e)
        {
            exceptionThrown = true;
        }

        Assert.That(exceptionThrown, Is.False);

    }

    [Test]
    public void TestInvalidUrl1()
    {
        bool exceptionThrown = false;

        try
        {
            BaseClient baseClient = new("");
        }
        catch (ConfigurationException ex)
        {
            exceptionThrown = true;
            Console.WriteLine(ex.Message);
            Console.WriteLine(ex.StackTrace);
        }

        Assert.That(exceptionThrown, Is.False);

    }

    [Test]
    public void Test()
    {
        bool exceptionThrown = false;

        try
        {
            BaseClient baseClient = new("https://api.pl");
        }
        catch (ConfigurationException)
        {
            exceptionThrown = true;
        }
        catch (ArgumentException)
        {
            Console.WriteLine("wystapil ArgumentException");
        }
        catch (Exception)
        {
            Console.WriteLine("wystapil Exception lub inny");
        }

        Assert.That(exceptionThrown, Is.False);
    }

    [Test]
    public void TestEmptyUrl()
    {
        BaseClient baseClient = new(string.Empty);
    }

    [Test]
    public void TestNullUrl()
    {
        BaseClient baseClient = new(null);
    }

    [Test]
    public void TestExceptionIsNotThrown()
    {
        Assert.DoesNotThrow(() => new BaseClient("https://api.test.pl"));
    }

    [Test]
    public void TestExceptionIsThrown()
    {
        Assert.Throws<ArgumentException>(() => new BaseClient(string.Empty));
    }
}
