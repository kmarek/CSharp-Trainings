﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Testerzy.Trainings.CSharp.Tests.Lab2G;

namespace Testerzy.Trainings.CSharp.Tests.Tasks;

public class Lab2GTests
{
    [Test]
    public void TestSendingRequests()
    {
        string url = "https://api.test.pl";

        var request = new RestRequest();
        request.Url = url;

        var client = new RestClient();

        string response1 = client.Send(request);
        Assert.That(response1, Is.EqualTo(url));

        string response2 = client.Send(request, "PUT");
        Assert.That(response2, Is.EqualTo($"PUT {url}"));
    }
}
