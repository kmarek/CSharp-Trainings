﻿namespace Testerzy.Trainings.CSharp.Tests.Lab2I;

public class BankAccount
{
    public string AccountNumber { get; set; }
}
