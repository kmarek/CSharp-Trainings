﻿namespace Testerzy.Trainings.CSharp.Tests.Enums;

public enum TestCategoryName
{
    Smoke,
    Sanity
}
