﻿namespace Testerzy.Trainings.CSharp.Tests.Lab10A;

public static class StringExtensions
{
    public static int ToInt(this string str)
    {
        return Convert.ToInt32(str);
    }

    public static int CountWords(this string str)
    {
        var array = str.Split(' ');
        return array.Length;
    }

    public static bool IsPalindrome(this string str)
    {
        string original = str.RemoveSpecialChars().ToLower();
        string reversed = string.Empty;

        var rev = original.ToCharArray().Reverse();
        string revs = string.Join("", rev);

        for (int i = original.Length - 1; i >= 0; i--)
        {
            reversed += original[i];
        }

        Console.WriteLine($"original '{original}'");
        Console.WriteLine($"reversed '{reversed}'");

        //return reversed == original;
        return original.Equals(reversed, StringComparison.OrdinalIgnoreCase);
    }

    public static bool IsPalindrome2(this string str)
    {
        string original = str.RemoveSpecialChars().ToLower();
        string reversed = "";

        for (int i = original.Length - 1; i >= 0; i--)
        {
            reversed += original[i];
            var rev = original[original.Length - i - 1];
            Console.WriteLine($"1: '{original[i]}'");
            Console.WriteLine($"2: '{rev}' {rev == original[i]}");
        }

        Console.WriteLine($"original '{original}'");
        Console.WriteLine($"reversed '{reversed}'");

        return original == reversed;
    }

    public static string RemoveSpecialChars(this string str)
    {
        return str
            .Replace(" ", string.Empty)
            .Replace(".", string.Empty)
            .Replace("?", string.Empty)
            .Replace(",", string.Empty);
    }
}
