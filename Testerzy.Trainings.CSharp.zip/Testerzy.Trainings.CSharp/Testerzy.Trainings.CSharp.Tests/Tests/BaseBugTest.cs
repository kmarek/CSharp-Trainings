﻿using Testerzy.Trainings.CSharp.Framework.Attributes;

namespace Testerzy.Trainings.CSharp.Tests.Tests;

public class BaseBugTest
{
    [SetUp]
    public void BaseSetUp()
    {
        SkipTestIfBugIsOpen();
    }

    public void SkipTestIfBugIsOpen()
    {
        string testName = TestContext.CurrentContext.Test.MethodName ?? string.Empty;
        var customAttributes = GetType()?.GetMethod(testName)?.GetCustomAttributes(true);

        List<BugAttribute> bugAttributes = customAttributes?.OfType<BugAttribute>().ToList() ?? [];
        if (bugAttributes.Count == 0)
        {
            return;
        }

        foreach (Attribute attribute in bugAttributes)
        {
            var properties = attribute.GetType().GetProperties();
            Console.WriteLine($"CustomAttribute :: Key: {attribute.GetType()}");
            foreach (var property in properties)
            {
                string value = property?.GetValue(attribute)?.ToString() ?? string.Empty;
                Console.WriteLine($"CustomAttribute :: {attribute.GetType()} PropertyName: {property.Name}:: Value: {value}");

                if (IsBugOpen(value))
                {
                    Assert.Ignore($"Skipping test because {value} is open.");
                }
            }
        }
    }

    public bool IsBugOpen(string bugId)
    {
        return bugId.Contains("123");
    }
}
