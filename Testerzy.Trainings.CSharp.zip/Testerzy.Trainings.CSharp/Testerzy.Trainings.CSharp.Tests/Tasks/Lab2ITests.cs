﻿using NUnit.Framework.Interfaces;
using Testerzy.Trainings.CSharp.Tests.Lab2I;
using Testerzy.Trainings.CSharp.Framework.Attributes;
using Testerzy.Trainings.CSharp.Tests.EncExamples;
using Testerzy.Trainings.CSharp.Tests.Attributes;
using Testerzy.Trainings.CSharp.Tests.Enums;

namespace Testerzy.Trainings.CSharp.Tests.Tasks;

//[Bug("JIRA DD-2323")]
public class Lab2ITests
{
    //[Bug]
    private string _name;

    // [Bug]
    [OneTimeSetUp]
    public void OneTimeSetUp()
    {
        string testName = TestContext.CurrentContext.Test.Name;
        Console.WriteLine(testName);
    }

    [SetUp]
    public void SetUp()
    {
        string testName = TestContext.CurrentContext.Test.Name;
        Console.WriteLine(testName);
    }

    [TearDown]
    public void TearDown()
    {
        string testName = TestContext.CurrentContext.Test.Name;
        TestStatus status = TestContext.CurrentContext.Result.Outcome.Status;

        if (status == TestStatus.Failed)
        {
            string screenshot = $"screenshot_{status}_{testName}.png";

            Console.WriteLine($"Zapisujemy screenshot do sciezki: {screenshot}");
        }


    }

    //[Bug("1232134")]
    [Test]
    [TestCategory(TestCategoryName.Smoke)]
    public void TestBankAccountNumber()
    {
        var bankAccount = DataHelper.GetValidBankAccount();

        Assert.That(bankAccount.AccountNumber, Is.EqualTo("PLsdsds12345678901234567890"));

        string testName = TestContext.CurrentContext.Test.Name;
        Console.WriteLine(testName);
    }
}
