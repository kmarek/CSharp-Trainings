﻿namespace Testerzy.Trainings.CSharp.Tests.EnumExamples;

public class Car
{
    private FuelType _fuelType;

    public Car(FuelType fuelType)
    {
        _fuelType = fuelType;
    }

    public FuelType GetFuelType()
    {
        return _fuelType;
    }
}
