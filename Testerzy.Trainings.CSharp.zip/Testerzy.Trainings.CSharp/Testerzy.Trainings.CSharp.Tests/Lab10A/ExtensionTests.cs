﻿namespace Testerzy.Trainings.CSharp.Tests.Lab10A;

public class ExtensionTests
{
    [Test]
    public void TestToInt()
    {
        int number = "12".ToInt();
        Assert.That(number, Is.EqualTo(12));
    }

    [Test]
    public void TestCountWords()
    {
        int wordCount = "Ala ma kota".CountWords();
        Assert.That(wordCount, Is.EqualTo(3));
    }

    [TestCase("Anna")]
    [TestCase("Popija rum As, samuraj i pop")]
    [TestCase("Ada raportuje, że jutro parada")]
    [TestCase("Może jeż łka jak łże jeżom")]
    [TestCase("O, ty z Katowic, Iwo? Tak, Zyto")]
    [TestCase("Łapał za kran, a kanarka złapał.")]
    [TestCase("Elf układał kufle.")]
    public void VerifyPalindromIsValid(string text)
    {
        bool isPalindrom = text.IsPalindrome();

        Assert.That(isPalindrom, Is.True);
    }

    [TestCase("Anna1")]
    [TestCase("Popija rum As, samuraj i pop1")]
    [TestCase("Ada raportuje, że jutro parada1")]
    [TestCase("Może jeż łka jak łże jeżom1")]
    [TestCase("O, ty z Katowic, Iwo? Tak, Zyto1")]
    [TestCase("Łapał za kran, a kanarka złapał.1")]
    [TestCase("Elf układał kufle.1")]
    public void VerifyPalindromIsInValid(string text)
    {
        bool isPalindrom = text.IsPalindrome();

        Assert.That(isPalindrom, Is.False);
    }
}
