﻿namespace Testerzy.Trainings.CSharp.Tests.Lab3;

public class ConfigurationException : Exception
{
    public ConfigurationException(string message) : base(message)
    {
        Console.WriteLine($"ConfigurationException: {message}");
    }
}
