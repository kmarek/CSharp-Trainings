﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Testerzy.Trainings.CSharp.Tests.Examples;

namespace Testerzy.Trainings.CSharp.Tests.Tests;

public class CompositionTests
{
    [Test]
    public void TestEmployee()
    {
        Address adres = new Address();
        adres.Street = "Topolowa";
        Employee pracownik1 = new Employee();
        pracownik1.LastName = "Doe";
        pracownik1.AdresKorespondencyjny = adres;

        Console.WriteLine(pracownik1.AdresKorespondencyjny.Street);
        Console.WriteLine(pracownik1.AdresZameldowania.Street);

        pracownik1.AdresKorespondencyjny.PostalCode = "32-444";


    }
}
