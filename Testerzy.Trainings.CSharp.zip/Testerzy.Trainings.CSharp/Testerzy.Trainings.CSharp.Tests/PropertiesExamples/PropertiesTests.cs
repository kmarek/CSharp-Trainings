﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testerzy.Trainings.CSharp.Tests.PropertiesExamples;

public class PropertiesTests
{
    [Test]
    public void TestProperty()
    {
        var car = new Car();

        car.color = "Red";
        //car.Color = "Red";

        string color1 = car.color;
        string color2 = car.Color;
        int wheelC = car.WheelCount;
        //car.WheelCount = 4;
    }
}
