﻿namespace Testerzy.Trainings.CSharp.Tests.Lab7B;

public class Settings
{
    public Environment Environment { get; set; }
    public List<User> Users { get; set; }
}
