﻿namespace Testerzy.Trainings.CSharp.Tests.Lab7B;

public class Environment
{
    public string Name { get; set; }
}
