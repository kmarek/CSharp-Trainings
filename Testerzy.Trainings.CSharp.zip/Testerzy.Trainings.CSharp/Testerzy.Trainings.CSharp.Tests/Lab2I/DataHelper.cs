﻿namespace Testerzy.Trainings.CSharp.Tests.Lab2I;

public static class DataHelper
{
    public static BankAccount GetValidBankAccount()
    {
        BankAccount bankAccount = new();
        bankAccount.AccountNumber = "PL12345678901234567890";
        return bankAccount;
    }
}
