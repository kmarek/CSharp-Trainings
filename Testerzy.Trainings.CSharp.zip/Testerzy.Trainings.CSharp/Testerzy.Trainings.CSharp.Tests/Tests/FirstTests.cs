﻿using Testerzy.Trainings.CSharp.Tests.Eamples2;

namespace Testerzy.Trainings.CSharp.Tests.Tests;

public class FirstTests
{
    [Test]
    public void TestException()
    {
        Console.WriteLine("1");

        Polonez polonez = new Polonez();
        polonez.Engine.Capacity = 1000; // NullReferenceException

        Console.WriteLine("2");
    }

    [Test]
    public void TestException2()
    {
        Console.WriteLine("1");

        int[] tablica = { 1, 2, 3 };
        Console.WriteLine($"element o indeksie 1 = {tablica[tablica.Length - 1]}");

        Console.WriteLine("2");
    }

    [Test]
    public void TestException4()
    {
        Console.WriteLine("1");

        int number = Convert.ToInt32("12dfsdfsdf3"); //FormatException
        Console.WriteLine("2");
    }

    [Test]
    public void FirstTest()
    {
        Console.WriteLine("Cos tu sobie logujemy");

        int actual = 1 + 1;
        int expected = 2;

        Assert.That(actual, Is.EqualTo(expected));
    }

    [Test]
    public void SecondTest() { }
}
