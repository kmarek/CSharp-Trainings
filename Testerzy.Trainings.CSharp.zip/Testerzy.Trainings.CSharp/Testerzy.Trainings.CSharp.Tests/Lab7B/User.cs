﻿namespace Testerzy.Trainings.CSharp.Tests.Lab7B;

public class User
{
    public string Email { get; set; }
    public bool IsAdmin { get; set; }
}
