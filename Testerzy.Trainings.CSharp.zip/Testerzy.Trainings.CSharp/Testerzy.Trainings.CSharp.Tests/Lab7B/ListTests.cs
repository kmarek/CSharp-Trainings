﻿using System.Text.Json;
using Testerzy.Trainings.CSharp.Tests.Extensions;

namespace Testerzy.Trainings.CSharp.Tests.Lab7B;

public class ListTests
{
    [Test]
    public void TestList()
    {
        int suma = 1.Dodaj(44);
        Assert.That(suma, Is.EqualTo(45));

        List<int> list = [1, 2, 3, 4];
        list.Add(1);
        list.Remove(3);

        Assert.That(list.Count, Is.EqualTo(4));
    }

    [Test]
    public void TestDeserializationStringToObject()
    {
        string json = "{\r\n\t\"environment\": {\r\n\t\t\"name\": \"dev\"\r\n\t},\r\n\t\"users\": [\r\n\t\t{\r\n\t\t\t\"email\": \"user@app.com\",\r\n\t\t\t\"isAdmin\": false\r\n\t\t},\r\n\t\t{\r\n\t\t\t\"email\": \"admin@app.com\",\r\n\t\t\t\"isAdmin\": true\r\n\t\t}\r\n\t]\r\n}\r\n";

        Settings settings = json.ConvertToSettings();// CreateSettings(json);

        //"dowowlwn".ConvertToSettings();

        List<User> lista = settings.Users;
        Assert.That(lista.Count, Is.EqualTo(2));

        Assert.That(settings.Environment.Name, Is.EqualTo("dev"));
        Assert.That(settings.Users[0].Email, Is.EqualTo("user@app.com"));
        Assert.That(settings.Users[0].IsAdmin, Is.False);
        Assert.That(settings.Users[1].Email, Is.EqualTo("admin@app.com"));
        Assert.That(settings.Users[1].IsAdmin, Is.True);
    }

    private Settings CreateSettings(string json)
    {
        Settings settings = JsonSerializer.Deserialize<Settings>(json, new JsonSerializerOptions() { PropertyNameCaseInsensitive = true });
        return settings;
    }
}
