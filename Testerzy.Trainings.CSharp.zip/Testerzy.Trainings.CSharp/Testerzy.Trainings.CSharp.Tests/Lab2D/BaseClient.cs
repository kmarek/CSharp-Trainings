﻿namespace Testerzy.Trainings.CSharp.Tests.Lab2D;

public class BaseClient
{
    string _baseUrl;

    public BaseClient(string baseUrl)
    {
        _baseUrl = baseUrl;
        Console.WriteLine($"Constructor BaseClient dla URL='{baseUrl}'");
    }

    [Obsolete("uzyj GetUrl()")]
    public string GetBaseUrl()
    {
        return _baseUrl;
    }


    public string GetUrl()
    {
        return _baseUrl;
    }
}
