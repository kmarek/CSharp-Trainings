﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testerzy.Trainings.CSharp.Tests.Examples;

public class BankAccount
{


    public static decimal PlnToEur { private get; set; }

    public decimal Balance { get; private set; }

    public BankAccount(decimal initialBalance)
    {
        Balance = initialBalance;
    }

    public decimal GetBalanceInEur()
    {
        return Balance / PlnToEur;
    }

    public static void StaticMethod2(int arg, string arg2)
    {

    }

    public static void MetodaStatyczna()
    {
        Console.WriteLine("");
        PlnToEur = 4;

        StaticMethod2(12, "test");

        int numbetr = GetInt();
    }

    protected static int GetInt()
    {
        return 12;
    }
}
