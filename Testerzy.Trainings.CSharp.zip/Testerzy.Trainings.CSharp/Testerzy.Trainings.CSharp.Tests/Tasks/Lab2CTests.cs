﻿using Testerzy.Trainings.CSharp.Tests.Lab2C;

namespace Testerzy.Trainings.CSharp.Tests.Tasks;

public class Lab2CTests
{
    [Test]
    public void TestPerson()
    {
        Person person = new Person();
        person.firstName = "Kamil";
        person.lastName = "Marek";
        //person.studentCardNumber = "AB/123/2024";

        Assert.That(person.lastName, Is.EqualTo("Kamil"));
        Assert.That(person.lastName, Is.EqualTo("Marek"));
    }

    [Test]
    public void TestStudent()
    {
        Student student = new Student();
        student.firstName = "Kamil";
        student.lastName = "Marek";
        student.studentCardNumber = "AB/123/2024";

        Assert.That(student.lastName, Is.EqualTo("Kamil"));
        Assert.That(student.lastName, Is.EqualTo("Marek"));
        Assert.That(student.studentCardNumber, Is.EqualTo("AB/123/2024"));
    }
}
