﻿namespace Testerzy.Trainings.CSharp.Tests.EncExamples;

public class KlasaPochodna : KlasaBazowa
{
    public int publicznePoleKlasaPochodna;

    public void PublicznaMetodaKlasaPochodna()
    {
        publicznePoleKlasaBazowa = 12;
        PublicznaMetodaKlasaBazowa();

        //prywatnePoleKlasaBazowa = 12;

        ProtectedMetodaKlasaBazowa();
    }
}
