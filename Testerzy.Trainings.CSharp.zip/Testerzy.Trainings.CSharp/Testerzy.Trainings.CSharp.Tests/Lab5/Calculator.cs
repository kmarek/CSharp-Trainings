﻿namespace Testerzy.Trainings.CSharp.Tests.Lab5;

public class Calculator
{
    public decimal Add(decimal a, decimal b)
    {
        return a + b;
    }

    public decimal Subtract(decimal a, decimal b)
    {
        return a - b;
    }
}
