﻿namespace Testerzy.Trainings.CSharp.Tests.Eamples2;

public class Polonez : Car
{
    public Engine Engine { get; set; }

    public Polonez() : base("Black")
    {
        Console.WriteLine("konstruktor POLONEZ");
    }

    public Polonez(string color) : base(color, 4)
    {
        Console.WriteLine($"konstruktor POLONEZ dla koloru {color}");
    }
}
