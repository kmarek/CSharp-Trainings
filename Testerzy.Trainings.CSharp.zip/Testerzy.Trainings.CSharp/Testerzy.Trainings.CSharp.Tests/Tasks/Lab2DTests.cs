﻿using Testerzy.Trainings.CSharp.Tests.Lab2D;

namespace Testerzy.Trainings.CSharp.Tests.Tasks;

public class Lab2DTests
{
    [Test]
    public void TestLab2D()
    {
        var baseT = new BaseClient("url");
        baseT.GetUrl();

        string url = "https://api.app.pl";

        var accountsClient = new AccountsClient(url);

        Assert.That(accountsClient.GetBaseUrl(), Is.EqualTo(url));
    }
}
