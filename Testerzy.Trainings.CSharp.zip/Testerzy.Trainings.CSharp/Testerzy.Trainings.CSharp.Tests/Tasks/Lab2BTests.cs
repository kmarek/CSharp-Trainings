﻿using Testerzy.Trainings.CSharp.Tests.Lab2B;

namespace Testerzy.Trainings.CSharp.Tests.Tasks;

public class Lab2BTests
{

    [Test]
    public void TestCreatingPerson_NoParams()
    {
        var person = new Person();

        Assert.That(person.firstName, Is.EqualTo(null));
        Assert.That(person.lastName != null && person.lastName == "Marek", Is.True);
    }

    [Test]
    public void TestCreatingPerson_FirstNameLastName()
    {
        string firstName = "Kamil";
        string lastName = "Marek";

        var person = new Person(firstName, lastName);

        Assert.That(person.firstName, Is.EqualTo(firstName));
        Assert.That(person.lastName, Is.EqualTo(lastName));
    }
}
