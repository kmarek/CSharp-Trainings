﻿using Testerzy.Trainings.CSharp.Tests.Examples;

namespace Testerzy.Trainings.CSharp.Tests.Tests;

public class InheritanceTests
{
    [Test]
    public void Test1()
    {
        var car = new Car();
        //car.CarMethod();
        //car.color = "Black";

        var bmw = new Bmw();
        bmw.bmwField = 12;
        bmw.BmwMethod();
        bmw.CarMethod();
        bmw.color = "Red";
        bmw.wheelCount = 4;

        var polonez = new Polonez();
        polonez.polonezField = 12;
        polonez.PolonezMethod();
        polonez.CarMethod();
        polonez.color = "Yellow";
        polonez.wheelCount = 4;
    }
}
