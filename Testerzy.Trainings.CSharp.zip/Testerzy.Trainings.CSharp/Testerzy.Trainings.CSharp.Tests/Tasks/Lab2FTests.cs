﻿using Testerzy.Trainings.CSharp.Tests.Lab2F;

namespace Testerzy.Trainings.CSharp.Tests.Tasks;

public class Lab2FTests
{
    [Test]
    public void TestProperty()
    {
        var person = new Person("John");
        //person.FirstName = "Dave";

        person.Introduce();
        person.Introduce("Dave");
        person.Introduce();

        Assert.That(person.FirstName, Is.EqualTo("John"));
    }

    [Test]
    public void TestAccountResponse()
    {
        var accountResponse = new AccountResponse();
        accountResponse.Email = "user@email.com";
        accountResponse.Username = "user12";
        accountResponse.FirstName = "John";
        accountResponse.LastName = "Doe";
        accountResponse.Age = 56;
        accountResponse.IsAdmin = false;



        var accountResponse2 = new AccountResponse()
        {
            Email = "user@email.com",
            Username = "user12",
            FirstName = "John",
            LastName = "Doe",
            Age = 56,
            IsAdmin = false
        };
    }
}
