﻿namespace Testerzy.Trainings.CSharp.Tests.Lab5;

public class Settings
{
    public string ApplicationUrl { get; set; }
}
