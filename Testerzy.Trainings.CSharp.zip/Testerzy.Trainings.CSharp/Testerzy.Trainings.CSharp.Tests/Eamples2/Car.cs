﻿namespace Testerzy.Trainings.CSharp.Tests.Eamples2;

public class Car
{
    public Car(string color)
    {
        Console.WriteLine($"konstruktor CAR dla koloru {color}");
    }

    public Car(string color, int wheelCount)
    {
        Console.WriteLine($"konstruktor CAR dla koloru {color} i wheelCount {wheelCount}");
    }
}
