﻿namespace Testerzy.Trainings.CSharp.Tests.EnumExamples;

public class EnumExamplesTests
{
    [Test]
    public void TestCarFuelType()
    {
        Car car1 = new Car(FuelType.Lpg);
        Car car2 = new Car(FuelType.Diesel);
        Car car3 = new Car(FuelType.Gasoline);
        Car car4 = new Car(FuelType.Electric);

        Console.WriteLine("lgp=" + FuelType.Lpg);
        Console.WriteLine("benzyna=" + FuelType.Gasoline.ToString());

        string zmienna = FuelType.Gasoline.ToString();

        Console.WriteLine("d jako int=" + (int)FuelType.Diesel);
        Console.WriteLine("g jako int=" + (int)FuelType.Gasoline);
        Console.WriteLine("lgp jako int=" + (int)FuelType.Lpg);
    }
}
