﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testerzy.Trainings.CSharp.Tests.Tests;

public class SetupTearDownTests : BaseTest
{
    [OneTimeSetUp]
    public void OneTimeSetUp()
    {
        Console.WriteLine("OneTimeSetUp");
    }

    [SetUp]
    public void SetUp()
    {
        Console.WriteLine("setup");
        //Assert.That(1 + 1, Is.EqualTo(0));
    }

    [TearDown]
    public void TearDown()
    {
        Console.WriteLine("teardown");
    }

    [Test]
    public void Test1()
    {
        Console.WriteLine("test1");
    }

    [Test]
    public void Test2()
    {
        Console.WriteLine("test2");
    }
}
