﻿namespace Testerzy.Trainings.CSharp.Tests.Lab7A;

public class ErrorRegistry
{
    private Dictionary<int, string> _errors;

    public ErrorRegistry()
    {
        _errors = new()
        {
            { 1012, "Invalid Token" },
            { 1013, "Invalid User" }
        };
    }



    public string GetError(int errorId)
    {
        string errorMessage;

        try
        {
            errorMessage = _errors[errorId];
        }
        catch
        {
            errorMessage = string.Empty;
        }

        return errorMessage;
    }

    public string GetError1(int errorId)
    {
        try
        {
            return _errors[errorId];
        }
        catch
        {
            return string.Empty;
        }
    }

    public string GetError2(int errorId)
    {
        foreach (var error in _errors)
        {
            if (error.Key == errorId)
            {
                return error.Value;
            }
        }

        return string.Empty;
    }

    public string GetError3(int errorId)
    {
        bool exists = _errors.ContainsKey(errorId);

        //if (exists)
        //{
        //    return _errors[errorId];
        //}
        //else
        //{
        //    return string.Empty;
        //}

        return exists ? _errors[errorId] : string.Empty;
    }
}
