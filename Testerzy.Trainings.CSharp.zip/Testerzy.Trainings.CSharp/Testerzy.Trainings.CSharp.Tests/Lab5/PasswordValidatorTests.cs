﻿namespace Testerzy.Trainings.CSharp.Tests.Lab5;

public class PasswordValidatorTests
{
    [TestCase("SomePassword!", false)]
    [TestCase("SOMEPASSWORD1!", false)]
    [TestCase("somepassword1!", false)]
    [TestCase("SomePassword1", false)]
    [TestCase("Passw1!", false)]
    [TestCase("TooLongPassword1!", false)]
    [TestCase("Enough1!", true)]
    [TestCase("StillG00dEnough!", true)] // BUG
    public void Should_ValidatePassword(string password, bool expectedResult)
    {
        var passwordValidator = new PasswordValidator();

        bool result = passwordValidator.IsPasswordValid(password);

        Assert.That(result, Is.EqualTo(expectedResult));
    }
}
