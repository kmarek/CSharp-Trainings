﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Testerzy.Trainings.CSharp.Tests.Lab7B;

namespace Testerzy.Trainings.CSharp.Tests.Extensions;

public static class StringExtensions
{
    public static Settings ConvertToSettings(this string json)
    {
        Settings settings = JsonSerializer.Deserialize<Settings>(json, new JsonSerializerOptions() { PropertyNameCaseInsensitive = true });
        return settings;
    }
}
