﻿using Testerzy.Trainings.CSharp.Tests.Lab2E;

namespace Testerzy.Trainings.CSharp.Tests.Tasks;

public class Lab2ETests
{
    [Test]
    public void TestDeposit()
    {
        var bankAccount = new BankAccount();
        bankAccount.Deposit(100m);
        Assert.That(bankAccount.GetBalance(), Is.EqualTo(100m));

        bankAccount.Deposit(200.99M);
        Assert.That(bankAccount.GetBalance(), Is.EqualTo(300.99m));
    }
}
