﻿namespace Testerzy.Trainings.CSharp.Tests.Tests;

public class ListExampleTests
{
    [Test]
    public void TestList1()
    {
        var lista1 = new List<string>();
        var lista2 = new List<string>()
        {
            "element 1",
            "element2",
            "element3"
        };
        Console.WriteLine($"Pierwszy element {lista2[0]}");

        lista2.Add("element4");
        lista2.Add("element 1");
        lista2.Add("element4");
        lista2.Add("element5");
        lista2.Remove("element 1");
        lista2.Remove("not exisiting");

        lista2[0] = "nowa wartosc";
        Console.WriteLine($"Pierwszy element {lista2[0]}");

        foreach (string item in lista2)
        {
            Console.WriteLine($"ele={item}");
        }

        List<string> lista3 = [
            "element 1",
            "element2"
            ];

        List<int> lista4 = [0, 34, 34, 34, 1, 1];
        List<Car> lista5 = [new Car(), new Car()];

        bool czyElementIstnieje = lista2.Contains("sdsd");

    }
}
