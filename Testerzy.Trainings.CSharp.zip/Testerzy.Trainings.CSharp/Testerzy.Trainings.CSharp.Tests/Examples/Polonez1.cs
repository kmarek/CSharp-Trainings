﻿namespace Testerzy.Trainings.CSharp.Tests.Examples;

public class Polonez1
{
    string color;

    public Polonez1()
    {
        Console.WriteLine("konstr bez parametrów");
    }

    public Polonez1(string color)
    {
        Console.WriteLine($"Tworze poloneza o kolorze {color}");
        this.color = color;
    }

    public void Doit()
    {

    }
}
