﻿namespace Testerzy.Trainings.CSharp.Tests.Lab2F;

public class AccountResponse
{
    public string Email { get; set; }
    public string Username { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public int Age { get; set; }
    public bool IsAdmin { get; set; }
}
