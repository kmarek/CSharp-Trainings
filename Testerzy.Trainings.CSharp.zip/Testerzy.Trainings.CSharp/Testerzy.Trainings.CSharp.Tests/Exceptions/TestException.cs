﻿namespace Testerzy.Trainings.CSharp.Tests.Exceptions;

public class TestException : Exception
{
    public TestException(string message) : base(message)
    {
        Console.WriteLine("Wystapił testexception");
        Console.WriteLine(message);
    }

    public TestException(string message, Exception innerException) : base(message, innerException)
    {
        Console.WriteLine("Wystapił testexception");
        Console.WriteLine(message);
    }
}
