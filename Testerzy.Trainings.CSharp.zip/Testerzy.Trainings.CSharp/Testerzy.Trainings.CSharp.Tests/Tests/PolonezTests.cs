﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Testerzy.Trainings.CSharp.Tests.Examples;

namespace Testerzy.Trainings.CSharp.Tests.Tests;

public class PolonezTests
{
    [Test]
    public void TestPolonez()
    {
        Polonez1 polonez1 = new Polonez1("Red");
        Polonez1 polonez1a;
        polonez1a = new Polonez1();
        var polonez2 = new Polonez1("Yellow");
        Polonez1 polonez3 = new();

        polonez1.Doit();
    }
}
