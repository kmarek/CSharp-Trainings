﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testerzy.Trainings.CSharp.Tests.Examples;

public class Employee
{
    public string LastName { get; set; } = "";
    public Address AdresZameldowania { get; set; } = new Address();
    public Address AdresKorespondencyjny { get; set; }

    public Employee()
    {
        AdresZameldowania = new Address();
        AdresKorespondencyjny = new Address();
    }
}
