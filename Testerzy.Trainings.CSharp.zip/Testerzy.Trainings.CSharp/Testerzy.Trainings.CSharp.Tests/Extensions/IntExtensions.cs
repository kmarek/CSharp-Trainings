﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testerzy.Trainings.CSharp.Tests.Extensions;

public static class IntExtensions
{
    public static int Dodaj(this int value, int coDodac)
    {
        return value + coDodac;
    }
}
