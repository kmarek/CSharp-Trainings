﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testerzy.Trainings.CSharp.Tests.Examples;

public static class Constants
{
    public const string Header = "HEADER NAME";
    public const string Header2 = "oiois";

    public static class ApiResponses
    {
        public const string AccountsEndpoint = "/Accounts";
    }
}
