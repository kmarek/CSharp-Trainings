﻿namespace Testerzy.Trainings.CSharp.Framework;

public class KlasaPublicznaFramework
{

}
