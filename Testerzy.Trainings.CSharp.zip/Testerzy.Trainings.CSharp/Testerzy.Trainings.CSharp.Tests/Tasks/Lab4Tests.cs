﻿using Testerzy.Trainings.CSharp.Framework.Attributes;
using Testerzy.Trainings.CSharp.Tests.Attributes;
using Testerzy.Trainings.CSharp.Tests.Enums;
using Testerzy.Trainings.CSharp.Tests.Lab4;
using Testerzy.Trainings.CSharp.Tests.Tests;
using DescriptionAttribute = Testerzy.Trainings.CSharp.Framework.Attributes.DescriptionAttribute;

namespace Testerzy.Trainings.CSharp.Tests.Tasks;

[Parallelizable(ParallelScope.All)]
//[Bug("1234")]
//[ImportantBug("ada")]
public class Lab4Tests : BaseBugTest
{
    //[Bug("1234")]
    const int retryCount = 12;
    static int tryCount;

    [OneTimeSetUp]
    public void OneTimeSetUp()
    {
        tryCount = 0;
    }

    [TestCase(Month.January, 0)]
    [TestCase(Month.May, 4)]
    [TestCase(Month.December, 11)]
    public void TestMonthNumber(Month month, int expectedIndex)
    {
        int number = (int)month;

        Assert.That(number, Is.EqualTo(expectedIndex));
    }

    [Test, Ignore("BUG 12345")]
    public void TestJanuaryNumber()
    {
        int number = (int)Month.January;

        Assert.That(number, Is.EqualTo(0));
    }

    [Test, Retry(5)]
    [TestCategory(TestCategoryName.Sanity)]
    public void TestAprilNumber()
    {
        int number = (int)Month.April;

        Assert.That(number, Is.EqualTo(++tryCount));

        Console.WriteLine("1");
        //Assert.Ignore("BUG 12345");
        Console.WriteLine("2");
    }

    [Test]
    //[Property("Category", "Smoke")]
    [TestCategory(TestCategoryName.Sanity)]
    public void TestMayNumber()
    {
        int number = (int)Month.May;

        Assert.That(number, Is.EqualTo(4));
    }

    [Test]
    public void TestDecemberNumber()
    {
        int number = (int)Month.December;

        Assert.That(number, Is.EqualTo(11));
    }

    [TestCase(Month.January, 200)]
    [TestCase(Month.May, 300)]
    [TestCase(Month.July, 400)]
    [TestCase(Month.August, 400)]
    public void TestPrice(Month month, int expectedPrice)
    {
        int price = PriceCalculator.GetPrice(month);

        Assert.That(price, Is.EqualTo(expectedPrice));
    }

    [Test]
    [Description("opis")]
    [TestCategory(TestCategoryName.Smoke)]
    public void TestPriceJanuary()
    {
        int price = PriceCalculator.GetPrice(Month.January);

        Assert.That(price, Is.EqualTo(200));
    }

    [Test]
    [Bug("BUG 1232455")]
    public void TestPriceMay()
    {
        int price = PriceCalculator.GetPrice(Month.May);

        Assert.That(price, Is.EqualTo(300));
    }

    [Test]
    [Bug("BUG 32")]
    public void TestPriceJuly()
    {
        int price = PriceCalculator.GetPrice(Month.July);

        Assert.That(price, Is.EqualTo(400));
    }
}
