﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testerzy.Trainings.CSharp.Tests.PropertiesExamples;

public class Car
{
    // pole
    public string color = "Black";

    // wlasciwosc
    public string Color { get; private set; } = "Black";

    public int WheelCount => 4;
}
