﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testerzy.Trainings.CSharp.Tests.EncExamples;

public class BankAccount
{
    private decimal _balance;

    public decimal GetBalance()
    {
        return _balance;
    }

    public void Wplac(decimal amount, int pin)
    {
        if (pin == 1234)
        {
            _balance = _balance + amount;

        }
    }

    public decimal Wyplac(decimal amount, int pin)
    {
        if (pin == 1234)
        {
            _balance = _balance - amount;
            return amount;
        }

        return 0m;
    }
}
