﻿namespace Testerzy.Trainings.CSharp.Tests.Eamples2;

public class Engine
{
    public int Capacity { get; set; }
}
