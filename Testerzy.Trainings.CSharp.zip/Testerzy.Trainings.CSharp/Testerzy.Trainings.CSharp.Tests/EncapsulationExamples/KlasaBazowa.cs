﻿namespace Testerzy.Trainings.CSharp.Tests.EncExamples;

public class KlasaBazowa
{
    public int publicznePoleKlasaBazowa;
    private int prywatnePoleKlasaBazowa;
    int pole;

    public void PublicznaMetodaKlasaBazowa()
    {
        publicznePoleKlasaBazowa = 12;
        prywatnePoleKlasaBazowa = 123;
    }

    protected void ProtectedMetodaKlasaBazowa()
    {

    }

    public void Metoda()
    {
        PublicznaMetodaKlasaBazowa();
        prywatnePoleKlasaBazowa = 9090;
    }
}
