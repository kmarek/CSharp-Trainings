﻿using Testerzy.Trainings.CSharp.Tests.Lab5;

namespace Testerzy.Trainings.CSharp.Tests;

[SetUpFixture]
public class GlobalSetup
{
    public static Settings Settings { get; set; }

    [OneTimeSetUp]
    public void GlobalSetUp()
    {
        Settings = new Settings();
        Settings.ApplicationUrl = "https://dev.app.com";
    }
}
