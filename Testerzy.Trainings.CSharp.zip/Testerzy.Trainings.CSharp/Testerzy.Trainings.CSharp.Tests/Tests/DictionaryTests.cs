﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Testerzy.Trainings.CSharp.Tests.Lab7A;

namespace Testerzy.Trainings.CSharp.Tests.Tests;

public class DictionaryTests
{
    [Test]
    public void TestDictionary()
    {
        var dictionary = new Dictionary<string, string>();
        dictionary.Add("Jan Kowalski", "jan@kowalski.pl");
        dictionary.Add("Maria Nowak", "maria@nowak.pl");

        foreach (var item in dictionary)
        {
            Console.WriteLine($"{item.Key}, email {item.Value}");
        }
    }

    [Test]
    public void TestErrorRegistry_ExistingKey()
    {
        var errorRegistry = new ErrorRegistry();
        string errorMessage = errorRegistry.GetError(1012);

        Assert.That(errorMessage, Is.Not.Empty);
    }

    [Test]
    public void TestErrorRegistry_NotExistingKey()
    {
        var errorRegistry = new ErrorRegistry();
        string errorMessage = errorRegistry.GetError(0);

        Assert.That(errorMessage, Is.Empty);
    }
}
