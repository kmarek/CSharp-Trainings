﻿using Testerzy.Trainings.CSharp.Tests.Lab5;

namespace Testerzy.Trainings.CSharp.Tests.Tasks;

[Parallelizable(ParallelScope.All)]
public class CalculatorTests : BaseCalculatorTests
{
    private Calculator _calculator;

    [OneTimeSetUp]
    public void OneTimeSetUp()
    {
        _calculator = new Calculator();
        string url = GlobalSetup.Settings.ApplicationUrl;
    }

    [Property("TestLevel", "UAT")]
    [TestCase(-1.1, -2.2, -3.3)]
    [TestCase(1.1, 2.2, 3.3)]
    [TestCase(-1.1, 2.2, 1.1)]
    [TestCase(-1.1, 0, -1.1)]
    [TestCase(0, 1.1, 1.1)]
    [TestCase(0, 0, 0)]
    public void TestCalculatorAdd(decimal a, decimal b, decimal expSum)
    {
        decimal sum = Calculator.Add(a, b);

        Assert.That(sum, Is.EqualTo(expSum));

        string url = GlobalSetup.Settings.ApplicationUrl;
        Console.WriteLine(url);
    }

    [TestCase(-1.1, -2.2, 1.1)]
    [TestCase(1.1, 2.2, -1.1)]
    [TestCase(-1.1, 2.2, -3.3)]
    [TestCase(-1.1, 0, -1.1)]
    [TestCase(0, 1.1, -1.1)]
    [TestCase(0, 0, 0)]
    public void TestCalculatorSubtract(decimal a, decimal b, decimal expDiff)
    {
        string testName = TestContext.CurrentContext.Test.Name;
        Console.WriteLine(testName);
        decimal sum = _calculator.Subtract(a, b);

        Assert.That(sum, Is.EqualTo(expDiff));
    }


    [Test, Pairwise]
    public void Test(
        [Values(-1, 0, 1)] int a,
        [Values(-2, 0, 2)] int b)
    {
        Console.WriteLine($"a={a}, b={b}");
    }
}
