﻿namespace Testerzy.Trainings.CSharp.Tests.Tests;

public class DictionaryExampleTests
{
    [Test]
    public void TestDict()
    {
        Dictionary<string, string> zmienna = new()
        {
            {"klucz1", "wartosc2" },
            {"klucz2", "wartosc2" },
            {"klucz3", "wartosc2" },
            {"klucz4", "wartosc2" },
            {"klucz5", "wartosc2" }
        };
    }

    [Test]
    public void TestDict2()
    {
        var car1 = new Car();
        car1.Color = "RED";

        var rejestrSamochodow = new Dictionary<string, Car>
        {
            {"KR123124", new Car() },
            {"WW0908", car1 }
        };

        rejestrSamochodow.Add("RP029024", new Car());
        //rejestrSamochodow.Add("RP029024", new Car());
        rejestrSamochodow.Add("KR029024", car1);

        rejestrSamochodow.Remove("WW0908");

        rejestrSamochodow.Remove("NIEISTNIEJE");

        int iloscPar = rejestrSamochodow.Count;
        Console.WriteLine($"iloscPar={iloscPar}");

        Car samochodRP029024 = rejestrSamochodow["RP029024"];
        //Car samochodR = rejestrSamochodow["NIEISTNIEJE"];
        //samochodRP029024.

        foreach (KeyValuePair<string, Car> paraTablicaRejAuto in rejestrSamochodow)
        {
            Console.WriteLine($"{paraTablicaRejAuto.Key} wartosc={paraTablicaRejAuto.Value.Color}");
        }

        foreach (string tablicaRejestracyjna in rejestrSamochodow.Keys)
        {
            Console.WriteLine($"tablicaRejestracyjna={tablicaRejestracyjna}");
        }

        foreach (Car samochod in rejestrSamochodow.Values)
        {
            Console.WriteLine($"kolor={samochod.Color}");
        }
    }
}
