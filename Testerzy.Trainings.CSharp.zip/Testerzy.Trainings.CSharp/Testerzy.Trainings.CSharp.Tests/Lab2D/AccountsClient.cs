﻿namespace Testerzy.Trainings.CSharp.Tests.Lab2D;

public class AccountsClient : BaseClient
{
    public AccountsClient(string baseUrl) : base(baseUrl)
    {
        Console.WriteLine($"Constructor AccountClient dla URL='{baseUrl}'");
    }
}
